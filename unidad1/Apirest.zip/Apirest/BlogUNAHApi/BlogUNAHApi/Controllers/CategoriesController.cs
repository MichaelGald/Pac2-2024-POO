﻿using BlogUNAHApi.Database.Entities;
using Microsoft.AspNetCore.Mvc;

namespace BlogUNAHApi.Controllers
{
    [ApiController]
    [Route("api/categories")]
    public class CategoriesController : ControllerBase
    {
        public List<Category> _categories { get; set; }

        public CategoriesController() 
        {
            _categories = new List<Category>();

            _categories.Add(new Category { Id = Guid.Parse("10687095-1364-4f76-be31-56f287a8c1f2"), Name = "JavaScript", Description = "El lenguaje mas entretenido del mundo mundial" });
            _categories.Add(new Category { Id = Guid.Parse("19eaec3d-0dd2-46a1-a279-f6e29c3c50ae"), Name = "IA", Description = "Tecnologia de moda 2024" });
            _categories.Add(new Category { Id = Guid.Parse("3c1ee6b6-4d44-4c84-80d8-979d0a8a6543"), Name = "NodeJS", Description = "No entiendo NodeJs" });
        }

        [HttpGet]
        public IActionResult GetAll() 
        {
            return Ok(_categories);
        }

        [HttpGet ("{Id}")]
        public ActionResult Get(Guid id)
        {
            var category = _categories.FirstOrDefault(c => c.Id == id);

            if (category == null) 
            {
                return NotFound(new { Message = $"No se encontro la categoria: {id}"});
            }

            return Ok(category);
        }
        [HttpPost]
        public ActionResult Create(Category category) 
        {
            _categories.Add(category);
            return null;

        }
     }
}
